"""Lapisan layanan (business logic): alur pesanan, stok, dan pembayaran."""
from models.db import get_db

# Status pesanan
MENUNGGU_BAYAR = "Menunggu Pembayaran"
MENUNGGU_VERIF = "Menunggu Verifikasi"
DIPROSES = "Diproses"
DIKIRIM = "Dikirim"
SELESAI = "Selesai"
DIBATALKAN = "Dibatalkan"

STEPS = [MENUNGGU_BAYAR, MENUNGGU_VERIF, DIPROSES, DIKIRIM, SELESAI]
ALL_STATUS = STEPS + [DIBATALKAN]

# Status pembayaran
P_BELUM = "Belum Dibayar"
P_VERIF = "Menunggu Verifikasi"
P_OK = "Terverifikasi"
P_TOLAK = "Ditolak"
P_COD = "Bayar di Tempat"

CUSTOMER_CAN_CANCEL = {MENUNGGU_BAYAR}
ADMIN_CAN_CANCEL = {MENUNGGU_BAYAR, MENUNGGU_VERIF, DIPROSES}


class OrderError(Exception):
    """Kesalahan alur pesanan yang pesannya aman ditampilkan ke pengguna."""


def _log(db, order_id, status, note=""):
    db.execute(
        "INSERT INTO order_history (order_id, status, note) VALUES (?,?,?)",
        (order_id, status, note),
    )


def _get_order(db, order_id):
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if order is None:
        raise OrderError("Pesanan tidak ditemukan.")
    return order


def create_order(user_id, cart, recipient, phone, address, method):
    """Buat pesanan dari keranjang {product_id: qty}. Stok dikurangi atomik."""
    if not cart:
        raise OrderError("Keranjang masih kosong.")
    db = get_db()
    try:
        total = 0
        lines = []
        for pid, qty in cart.items():
            p = db.execute(
                "SELECT id, name, price FROM products WHERE id = ? AND is_active = 1", (pid,)
            ).fetchone()
            if p is None:
                raise OrderError("Ada produk di keranjang yang sudah tidak tersedia.")
            cur = db.execute(
                "UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?",
                (qty, p["id"], qty),
            )
            if cur.rowcount == 0:
                raise OrderError(f"Stok {p['name']} tidak mencukupi.")
            total += p["price"] * qty
            lines.append((p, qty))

        cod = method == "COD"
        status = DIPROSES if cod else MENUNGGU_BAYAR
        cur = db.execute(
            "INSERT INTO orders (user_id, recipient, phone, address, total, payment_method, status)"
            " VALUES (?,?,?,?,?,?,?)",
            (user_id, recipient, phone, address, total, method, status),
        )
        order_id = cur.lastrowid
        for p, qty in lines:
            db.execute(
                "INSERT INTO order_items (order_id, product_id, product_name, price, qty) VALUES (?,?,?,?,?)",
                (order_id, p["id"], p["name"], p["price"], qty),
            )
        db.execute(
            "INSERT INTO payments (order_id, method, status) VALUES (?,?,?)",
            (order_id, method, P_COD if cod else P_BELUM),
        )
        _log(db, order_id, status, "Pesanan dibuat (bayar di tempat)." if cod else "Pesanan dibuat.")
        db.commit()
        return order_id
    except Exception:
        db.rollback()
        raise


def submit_proof(order_id, filename):
    """Pelanggan mengunggah bukti bayar."""
    db = get_db()
    order = _get_order(db, order_id)
    if order["payment_method"] == "COD":
        raise OrderError("Pesanan COD tidak perlu bukti pembayaran.")
    if order["status"] != MENUNGGU_BAYAR:
        raise OrderError("Bukti bayar hanya bisa diunggah saat status Menunggu Pembayaran.")
    db.execute(
        "UPDATE payments SET proof_file = ?, status = ?, note = NULL, paid_at = CURRENT_TIMESTAMP WHERE order_id = ?",
        (filename, P_VERIF, order_id),
    )
    db.execute("UPDATE orders SET status = ? WHERE id = ?", (MENUNGGU_VERIF, order_id))
    _log(db, order_id, MENUNGGU_VERIF, "Bukti pembayaran diunggah.")
    db.commit()


def verify_payment(order_id, accept, note=""):
    """Admin menerima atau menolak bukti pembayaran."""
    db = get_db()
    order = _get_order(db, order_id)
    if order["status"] != MENUNGGU_VERIF:
        raise OrderError("Pembayaran ini tidak sedang menunggu verifikasi.")
    if accept:
        db.execute(
            "UPDATE payments SET status = ?, verified_at = CURRENT_TIMESTAMP WHERE order_id = ?",
            (P_OK, order_id),
        )
        db.execute("UPDATE orders SET status = ? WHERE id = ?", (DIPROSES, order_id))
        _log(db, order_id, DIPROSES, "Pembayaran terverifikasi.")
    else:
        if not note.strip():
            raise OrderError("Isi alasan penolakan agar pelanggan tahu apa yang harus diperbaiki.")
        db.execute("UPDATE payments SET status = ?, note = ? WHERE order_id = ?", (P_TOLAK, note.strip(), order_id))
        db.execute("UPDATE orders SET status = ? WHERE id = ?", (MENUNGGU_BAYAR, order_id))
        _log(db, order_id, MENUNGGU_BAYAR, f"Pembayaran ditolak: {note.strip()}")
    db.commit()


def advance(order_id, tracking_no=""):
    """Diproses -> Dikirim -> Selesai."""
    db = get_db()
    order = _get_order(db, order_id)
    if order["status"] == DIPROSES:
        db.execute(
            "UPDATE orders SET status = ?, tracking_no = ? WHERE id = ?",
            (DIKIRIM, tracking_no.strip() or None, order_id),
        )
        _log(db, order_id, DIKIRIM, f"Dikirim. No. resi: {tracking_no.strip()}" if tracking_no.strip() else "Dikirim.")
    elif order["status"] == DIKIRIM:
        db.execute("UPDATE orders SET status = ? WHERE id = ?", (SELESAI, order_id))
        if order["payment_method"] == "COD":
            db.execute(
                "UPDATE payments SET status = ?, verified_at = CURRENT_TIMESTAMP WHERE order_id = ?",
                (P_OK, order_id),
            )
        _log(db, order_id, SELESAI, "Pesanan diterima pelanggan.")
    else:
        raise OrderError("Status pesanan ini tidak bisa dilanjutkan.")
    db.commit()


def cancel(order_id, by_admin=False):
    """Batalkan pesanan dan kembalikan stok."""
    db = get_db()
    order = _get_order(db, order_id)
    allowed = ADMIN_CAN_CANCEL if by_admin else CUSTOMER_CAN_CANCEL
    if order["status"] not in allowed:
        raise OrderError("Pesanan pada status ini tidak bisa dibatalkan.")
    try:
        for it in db.execute("SELECT product_id, qty FROM order_items WHERE order_id = ?", (order_id,)):
            db.execute("UPDATE products SET stock = stock + ? WHERE id = ?", (it["qty"], it["product_id"]))
        db.execute("UPDATE orders SET status = ? WHERE id = ?", (DIBATALKAN, order_id))
        _log(db, order_id, DIBATALKAN, "Dibatalkan oleh admin." if by_admin else "Dibatalkan oleh pelanggan.")
        db.commit()
    except Exception:
        db.rollback()
        raise
