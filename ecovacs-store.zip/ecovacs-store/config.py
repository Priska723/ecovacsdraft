import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "ganti-kunci-ini-sebelum-dipakai")
    DATABASE = os.path.join(BASE_DIR, "instance", "ecovacs.db")
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
    MAX_CONTENT_LENGTH = 2 * 1024 * 1024  # bukti bayar maks 2 MB
    ALLOWED_PROOF = {"png", "jpg", "jpeg", "pdf"}

    # Gambar produk diambil dari website lama jika belum ada di static/img
    IMAGE_BASE = "https://105841101725-glitch.github.io/WEBSITE-IKLAN-ECOVAS/"

    PAYMENT_METHODS = ["Transfer Bank", "QRIS / E-Wallet", "COD"]
    PAYMENT_INFO = {
        "Transfer Bank": "Transfer ke Bank Contoh 123-456-7890 a.n. ECOVACS Store (data contoh).",
        "QRIS / E-Wallet": "Bayar ke e-wallet 0812-0000-0000 a.n. ECOVACS Store (data contoh).",
        "COD": "Bayar tunai saat barang diterima.",
    }
