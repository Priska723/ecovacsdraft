import re

from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from controllers.utils import safe_next
from models.db import get_db, query

bp = Blueprint("auth", __name__)
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        error = None
        if not name:
            error = "Nama wajib diisi."
        elif not EMAIL_RE.match(email):
            error = "Format email belum benar."
        elif len(password) < 6:
            error = "Kata sandi minimal 6 karakter."
        elif password != confirm:
            error = "Konfirmasi kata sandi tidak sama."
        elif query("SELECT id FROM users WHERE email = ?", (email,), one=True):
            error = "Email ini sudah terdaftar. Silakan masuk."
        if error:
            flash(error, "error")
        else:
            db = get_db()
            db.execute(
                "INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?, 'customer')",
                (name, email, generate_password_hash(password)),
            )
            db.commit()
            flash("Akun berhasil dibuat. Silakan masuk.", "ok")
            return redirect(url_for("auth.login"))
    return render_template("register.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = query("SELECT * FROM users WHERE email = ?", (email,), one=True)
        if user is None or not check_password_hash(user["password_hash"], password):
            flash("Email atau kata sandi salah.", "error")
        else:
            cart = session.get("cart", {})
            session.clear()
            session["user_id"] = user["id"]
            session["cart"] = cart
            default = url_for("admin.dashboard") if user["role"] == "admin" else url_for("shop.index")
            return redirect(safe_next(request.args.get("next")) or default)
    return render_template("login.html")


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("Kamu sudah keluar.", "ok")
    return redirect(url_for("shop.index"))
