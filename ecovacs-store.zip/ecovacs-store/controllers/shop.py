import os
import re
import uuid

from flask import (Blueprint, abort, current_app, flash, g, redirect,
                   render_template, request, session, url_for)

from controllers.utils import login_required
from models.db import query
from services import order_service as svc

bp = Blueprint("shop", __name__)
PHONE_RE = re.compile(r"^\+?[0-9]{9,15}$")


# ---------- helper keranjang ----------
def cart_lines():
    lines, total = [], 0
    for pid, qty in session.get("cart", {}).items():
        p = query("SELECT * FROM products WHERE id = ? AND is_active = 1", (pid,), one=True)
        if p is None:
            continue
        sub = p["price"] * qty
        total += sub
        lines.append({"product": p, "qty": qty, "subtotal": sub})
    return lines, total


def _valid_upload(file):
    """Cek ekstensi dan 'magic bytes' agar file benar-benar gambar/PDF."""
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in current_app.config["ALLOWED_PROOF"]:
        return None
    head = file.stream.read(8)
    file.stream.seek(0)
    ok = (head.startswith(b"\x89PNG") and ext == "png") or \
         (head.startswith(b"\xff\xd8") and ext in ("jpg", "jpeg")) or \
         (head.startswith(b"%PDF") and ext == "pdf")
    return ext if ok else None


def _own_order(order_id):
    order = query("SELECT * FROM orders WHERE id = ? AND user_id = ?", (order_id, g.user["id"]), one=True)
    if order is None:
        abort(404)
    return order


# ---------- halaman publik ----------
@bp.route("/")
def index():
    rows = query(
        "SELECT p.*, c.name AS category FROM products p JOIN categories c ON c.id = p.category_id"
        " WHERE p.is_active = 1 ORDER BY p.id"
    )
    featured, seen = [], set()
    for r in rows:
        if r["category"] not in seen:
            seen.add(r["category"])
            featured.append(r)
    return render_template("index.html", featured=featured)


@bp.route("/about")
def about():
    return render_template("about.html")


@bp.route("/contact")
def contact():
    return render_template("contact.html")


@bp.route("/products")
def products():
    q = request.args.get("q", "").strip()
    cat = request.args.get("cat", type=int)
    sql = ("SELECT p.*, c.name AS category FROM products p JOIN categories c ON c.id = p.category_id"
           " WHERE p.is_active = 1")
    args = []
    if q:
        sql += " AND (p.name LIKE ? OR p.description LIKE ?)"
        args += [f"%{q}%", f"%{q}%"]
    if cat:
        sql += " AND p.category_id = ?"
        args.append(cat)
    sql += " ORDER BY p.category_id, p.id"
    return render_template("products.html", products=query(sql, args),
                           categories=query("SELECT * FROM categories ORDER BY id"), q=q, cat=cat)


# ---------- keranjang ----------
@bp.route("/cart")
def cart():
    lines, total = cart_lines()
    return render_template("cart.html", lines=lines, total=total)


@bp.route("/cart/add/<int:pid>", methods=["POST"])
def cart_add(pid):
    p = query("SELECT * FROM products WHERE id = ? AND is_active = 1", (pid,), one=True)
    if p is None:
        abort(404)
    cart = session.get("cart", {})
    have = cart.get(str(pid), 0)
    if p["stock"] <= 0:
        flash(f"{p['name']} sedang habis.", "error")
    elif have + 1 > p["stock"]:
        flash(f"Stok {p['name']} hanya {p['stock']} unit.", "warn")
    else:
        cart[str(pid)] = have + 1
        session["cart"] = cart
        flash(f"{p['name']} masuk keranjang.", "ok")
    return redirect(request.referrer or url_for("shop.products"))


@bp.route("/cart/update", methods=["POST"])
def cart_update():
    cart = {}
    for pid in session.get("cart", {}):
        p = query("SELECT stock FROM products WHERE id = ? AND is_active = 1", (pid,), one=True)
        try:
            qty = int(request.form.get(f"qty_{pid}", 0))
        except ValueError:
            qty = 0
        if p and qty > 0:
            cart[pid] = min(qty, p["stock"])
    session["cart"] = cart
    flash("Keranjang diperbarui.", "ok")
    return redirect(url_for("shop.cart"))


@bp.route("/cart/remove/<int:pid>", methods=["POST"])
def cart_remove(pid):
    cart = session.get("cart", {})
    cart.pop(str(pid), None)
    session["cart"] = cart
    return redirect(url_for("shop.cart"))


# ---------- checkout ----------
@bp.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    lines, total = cart_lines()
    if not lines:
        flash("Keranjang masih kosong.", "warn")
        return redirect(url_for("shop.products"))
    form = {"recipient": g.user["name"], "phone": "", "address": "", "method": "Transfer Bank"}
    if request.method == "POST":
        form = {k: request.form.get(k, "").strip() for k in ("recipient", "phone", "address", "method")}
        phone = form["phone"].replace(" ", "").replace("-", "")
        error = None
        if not form["recipient"]:
            error = "Nama penerima wajib diisi."
        elif not PHONE_RE.match(phone):
            error = "Nomor telepon harus 9–15 digit angka."
        elif len(form["address"]) < 10:
            error = "Alamat terlalu singkat. Tulis lengkap dengan kota dan kode pos."
        elif form["method"] not in current_app.config["PAYMENT_METHODS"]:
            error = "Pilih metode pembayaran."
        if error:
            flash(error, "error")
        else:
            cart = {pid: qty for pid, qty in session.get("cart", {}).items()}
            try:
                oid = svc.create_order(g.user["id"], cart, form["recipient"], phone, form["address"], form["method"])
            except svc.OrderError as e:
                flash(str(e), "error")
                return redirect(url_for("shop.cart"))
            session["cart"] = {}
            flash("Pesanan dibuat." if form["method"] == "COD" else "Pesanan dibuat. Lanjutkan dengan membayar.", "ok")
            return redirect(url_for("shop.order_detail", order_id=oid))
    return render_template("checkout.html", lines=lines, total=total, form=form)


# ---------- pesanan pelanggan ----------
@bp.route("/orders")
@login_required
def orders():
    rows = query("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC", (g.user["id"],))
    return render_template("orders.html", orders=rows)


@bp.route("/orders/<int:order_id>")
@login_required
def order_detail(order_id):
    order = _own_order(order_id)
    return render_template(
        "order_detail.html", order=order, steps=svc.STEPS,
        items=query("SELECT * FROM order_items WHERE order_id = ?", (order_id,)),
        payment=query("SELECT * FROM payments WHERE order_id = ?", (order_id,), one=True),
        history=query("SELECT * FROM order_history WHERE order_id = ? ORDER BY id DESC", (order_id,)),
    )


@bp.route("/orders/<int:order_id>/pay", methods=["POST"])
@login_required
def order_pay(order_id):
    _own_order(order_id)
    file = request.files.get("proof")
    if file is None or not file.filename:
        flash("Pilih file bukti pembayaran (PNG, JPG, atau PDF).", "error")
        return redirect(url_for("shop.order_detail", order_id=order_id))
    ext = _valid_upload(file)
    if ext is None:
        flash("File harus berupa PNG, JPG, atau PDF yang valid.", "error")
        return redirect(url_for("shop.order_detail", order_id=order_id))
    name = f"{uuid.uuid4().hex}.{ext}"
    try:
        svc.submit_proof(order_id, name)
    except svc.OrderError as e:
        flash(str(e), "error")
    else:
        file.save(os.path.join(current_app.config["UPLOAD_FOLDER"], name))
        flash("Bukti pembayaran terkirim. Admin akan memverifikasinya.", "ok")
    return redirect(url_for("shop.order_detail", order_id=order_id))


@bp.route("/orders/<int:order_id>/cancel", methods=["POST"])
@login_required
def order_cancel(order_id):
    _own_order(order_id)
    try:
        svc.cancel(order_id)
        flash("Pesanan dibatalkan dan stok dikembalikan.", "ok")
    except svc.OrderError as e:
        flash(str(e), "error")
    return redirect(url_for("shop.order_detail", order_id=order_id))


@bp.route("/orders/<int:order_id>/received", methods=["POST"])
@login_required
def order_received(order_id):
    order = _own_order(order_id)
    if order["status"] != svc.DIKIRIM:
        flash("Pesanan belum dikirim.", "error")
    else:
        svc.advance(order_id)
        flash("Terima kasih. Pesanan ditandai selesai.", "ok")
    return redirect(url_for("shop.order_detail", order_id=order_id))
