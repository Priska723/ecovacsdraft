from flask import Blueprint, abort, flash, redirect, render_template, request, url_for

from controllers.utils import admin_required
from models.db import get_db, query
from services import order_service as svc

bp = Blueprint("admin", __name__, url_prefix="/admin")


def _order_or_404(order_id):
    order = query(
        "SELECT o.*, u.name AS customer, u.email FROM orders o JOIN users u ON u.id = o.user_id WHERE o.id = ?",
        (order_id,), one=True)
    if order is None:
        abort(404)
    return order


# ---------- dashboard ----------
@bp.route("/")
@admin_required
def dashboard():
    by_status = {r["status"]: r["c"] for r in query("SELECT status, COUNT(*) c FROM orders GROUP BY status")}
    revenue = query(
        "SELECT COALESCE(SUM(o.total),0) t FROM orders o JOIN payments p ON p.order_id = o.id"
        " WHERE p.status = ? AND o.status != ?", (svc.P_OK, svc.DIBATALKAN), one=True)["t"]
    top = query(
        "SELECT oi.product_name, SUM(oi.qty) q FROM order_items oi JOIN orders o ON o.id = oi.order_id"
        " WHERE o.status != ? GROUP BY oi.product_name ORDER BY q DESC LIMIT 5", (svc.DIBATALKAN,))
    low = query("SELECT * FROM products WHERE is_active = 1 AND stock <= 3 ORDER BY stock, name")
    return render_template("admin/dashboard.html", by_status=by_status, revenue=revenue, top=top, low=low,
                           statuses=svc.ALL_STATUS, total_orders=sum(by_status.values()))


# ---------- pesanan masuk ----------
@bp.route("/orders")
@admin_required
def orders():
    status = request.args.get("status", "")
    sql = "SELECT o.*, u.name AS customer FROM orders o JOIN users u ON u.id = o.user_id"
    args = []
    if status in svc.ALL_STATUS:
        sql += " WHERE o.status = ?"
        args.append(status)
    sql += " ORDER BY o.id DESC"
    return render_template("admin/orders.html", orders=query(sql, args), status=status, statuses=svc.ALL_STATUS)


@bp.route("/orders/<int:order_id>")
@admin_required
def order_detail(order_id):
    order = _order_or_404(order_id)
    return render_template(
        "admin/order_detail.html", order=order, steps=svc.STEPS,
        items=query("SELECT * FROM order_items WHERE order_id = ?", (order_id,)),
        payment=query("SELECT * FROM payments WHERE order_id = ?", (order_id,), one=True),
        history=query("SELECT * FROM order_history WHERE order_id = ? ORDER BY id DESC", (order_id,)),
        can_cancel=order["status"] in svc.ADMIN_CAN_CANCEL,
    )


@bp.route("/orders/<int:order_id>/verify", methods=["POST"])
@admin_required
def order_verify(order_id):
    _order_or_404(order_id)
    accept = request.form.get("decision") == "accept"
    try:
        svc.verify_payment(order_id, accept, request.form.get("note", ""))
        flash("Pembayaran diterima. Pesanan masuk proses." if accept else "Pembayaran ditolak.", "ok")
    except svc.OrderError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.order_detail", order_id=order_id))


@bp.route("/orders/<int:order_id>/advance", methods=["POST"])
@admin_required
def order_advance(order_id):
    _order_or_404(order_id)
    try:
        svc.advance(order_id, request.form.get("tracking_no", ""))
        flash("Status pesanan diperbarui.", "ok")
    except svc.OrderError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.order_detail", order_id=order_id))


@bp.route("/orders/<int:order_id>/cancel", methods=["POST"])
@admin_required
def order_cancel(order_id):
    _order_or_404(order_id)
    try:
        svc.cancel(order_id, by_admin=True)
        flash("Pesanan dibatalkan dan stok dikembalikan.", "ok")
    except svc.OrderError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.order_detail", order_id=order_id))


# ---------- kelola produk ----------
def _product_form():
    f = request.form
    data = {
        "name": f.get("name", "").strip(),
        "category_id": f.get("category_id", type=int),
        "description": f.get("description", "").strip(),
        "price": f.get("price", type=int),
        "stock": f.get("stock", type=int),
        "image": f.get("image", "").strip(),
        "is_active": 1 if f.get("is_active") else 0,
    }
    error = None
    if not data["name"]:
        error = "Nama produk wajib diisi."
    elif not query("SELECT id FROM categories WHERE id = ?", (data["category_id"],), one=True):
        error = "Pilih kategori."
    elif data["price"] is None or data["price"] < 0:
        error = "Harga harus berupa angka 0 atau lebih."
    elif data["stock"] is None or data["stock"] < 0:
        error = "Stok harus berupa angka 0 atau lebih."
    return data, error


@bp.route("/products")
@admin_required
def products():
    rows = query("SELECT p.*, c.name AS category FROM products p JOIN categories c ON c.id = p.category_id ORDER BY p.id")
    return render_template("admin/products.html", products=rows)


@bp.route("/products/new", methods=["GET", "POST"])
@admin_required
def product_new():
    data = {"name": "", "category_id": None, "description": "", "price": 0, "stock": 0, "image": "", "is_active": 1}
    if request.method == "POST":
        data, error = _product_form()
        if error:
            flash(error, "error")
        else:
            db = get_db()
            db.execute(
                "INSERT INTO products (category_id, name, description, price, stock, image, is_active)"
                " VALUES (:category_id, :name, :description, :price, :stock, :image, :is_active)", data)
            db.commit()
            flash("Produk ditambahkan.", "ok")
            return redirect(url_for("admin.products"))
    return render_template("admin/product_form.html", p=data, categories=query("SELECT * FROM categories"), is_new=True)


@bp.route("/products/<int:pid>/edit", methods=["GET", "POST"])
@admin_required
def product_edit(pid):
    p = query("SELECT * FROM products WHERE id = ?", (pid,), one=True)
    if p is None:
        abort(404)
    if request.method == "POST":
        data, error = _product_form()
        if error:
            flash(error, "error")
            p = {**data, "id": pid}
        else:
            data["id"] = pid
            db = get_db()
            db.execute(
                "UPDATE products SET category_id=:category_id, name=:name, description=:description, price=:price,"
                " stock=:stock, image=:image, is_active=:is_active WHERE id=:id", data)
            db.commit()
            flash("Produk diperbarui.", "ok")
            return redirect(url_for("admin.products"))
    return render_template("admin/product_form.html", p=p, categories=query("SELECT * FROM categories"), is_new=False)


@bp.route("/products/<int:pid>/toggle", methods=["POST"])
@admin_required
def product_toggle(pid):
    db = get_db()
    db.execute("UPDATE products SET is_active = 1 - is_active WHERE id = ?", (pid,))
    db.commit()
    flash("Status tampil produk diubah.", "ok")
    return redirect(url_for("admin.products"))
