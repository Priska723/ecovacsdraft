"""Pengujian alur utama. Jalankan: python -m unittest discover -s tests -v"""
import io
import os
import re
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app  # noqa: E402

PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 64


class Client:
    """Pembungkus test client yang otomatis mengirim token CSRF."""

    def __init__(self, app):
        self.c = app.test_client()

    def token(self, path="/login"):
        html = self.c.get(path).get_data(as_text=True)
        return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)

    def post(self, path, data=None, **kw):
        data = dict(data or {})
        data["csrf_token"] = self.token()
        return self.c.post(path, data=data, follow_redirects=True, **kw)

    def get(self, path):
        return self.c.get(path, follow_redirects=True)


class FlowTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app({
            "TESTING": True,
            "DATABASE": os.path.join(self.tmp.name, "t.db"),
            "UPLOAD_FOLDER": os.path.join(self.tmp.name, "up"),
        })

    def tearDown(self):
        self.tmp.cleanup()

    def login(self, email, pw):
        c = Client(self.app)
        r = c.post("/login", {"email": email, "password": pw})
        self.assertIn("Keluar", r.get_data(as_text=True))
        return c

    def stock(self, pid):
        from models.db import query
        with self.app.app_context():
            return query("SELECT stock FROM products WHERE id=?", (pid,), one=True)["stock"]

    def checkout(self, c, method="Transfer Bank", pid=1, times=1):
        for _ in range(times):
            c.post(f"/cart/add/{pid}")
        return c.post("/checkout", {"recipient": "Budi", "phone": "081234567890",
                                    "address": "Jl. Perintis Kemerdekaan No. 1, Makassar", "method": method})

    def test_public_pages(self):
        c = Client(self.app)
        for p in ("/", "/about", "/contact", "/products", "/products?q=WINBOT", "/cart", "/login", "/register"):
            self.assertEqual(c.get(p).status_code, 200, p)
        self.assertEqual(c.get("/nope").status_code, 404)

    def test_register_and_login_errors(self):
        c = Client(self.app)
        r = c.post("/register", {"name": "A", "email": "bad", "password": "123456", "confirm": "123456"})
        self.assertIn("Format email", r.get_data(as_text=True))
        r = c.post("/register", {"name": "Ani", "email": "ani@x.id", "password": "secret1", "confirm": "secret1"})
        self.assertIn("Akun berhasil dibuat", r.get_data(as_text=True))
        r = c.post("/login", {"email": "ani@x.id", "password": "salah"})
        self.assertIn("salah", r.get_data(as_text=True))

    def test_protected_routes(self):
        c = Client(self.app)
        self.assertIn("Masuk dulu", c.get("/orders").get_data(as_text=True))
        cust = self.login("demo@ecovacs.test", "demo123")
        self.assertEqual(cust.c.get("/admin/").status_code, 403)

    def test_csrf_required(self):
        c = self.app.test_client()
        self.assertEqual(c.post("/login", data={"email": "a", "password": "b"}).status_code, 400)

    def test_full_transfer_flow(self):
        cust = self.login("demo@ecovacs.test", "demo123")
        before = self.stock(1)
        r = self.checkout(cust, times=2)
        self.assertIn("ECO-00001", r.get_data(as_text=True))
        self.assertEqual(self.stock(1), before - 2)

        # upload bukti: file palsu ditolak, PNG valid diterima
        r = cust.post("/orders/1/pay", {"proof": (io.BytesIO(b"bukan gambar"), "x.png")},
                      content_type="multipart/form-data")
        self.assertIn("harus berupa PNG", r.get_data(as_text=True))
        r = cust.post("/orders/1/pay", {"proof": (io.BytesIO(PNG), "bukti.png")},
                      content_type="multipart/form-data")
        self.assertIn("Bukti pembayaran terkirim", r.get_data(as_text=True))

        admin = self.login("admin@ecovacs.test", "admin123")
        r = admin.post("/admin/orders/1/verify", {"decision": "reject", "note": ""})
        self.assertIn("Isi alasan", r.get_data(as_text=True))
        r = admin.post("/admin/orders/1/verify", {"decision": "reject", "note": "Nominal kurang"})
        self.assertIn("Nominal kurang", cust.get("/orders/1").get_data(as_text=True))

        cust.post("/orders/1/pay", {"proof": (io.BytesIO(PNG), "bukti2.png")}, content_type="multipart/form-data")
        admin.post("/admin/orders/1/verify", {"decision": "accept"})
        admin.post("/admin/orders/1/advance", {"tracking_no": "JNE123"})
        html = cust.get("/orders/1").get_data(as_text=True)
        self.assertIn("JNE123", html)
        cust.post("/orders/1/received")
        self.assertIn("Selesai", cust.get("/orders/1").get_data(as_text=True))
        dash = admin.get("/admin/").get_data(as_text=True)
        self.assertIn("Rp 25.998.000", dash)  # 2 x 12.999.000 terverifikasi

    def test_cod_flow(self):
        cust = self.login("demo@ecovacs.test", "demo123")
        self.checkout(cust, method="COD", pid=2)
        admin = self.login("admin@ecovacs.test", "admin123")
        self.assertIn("Diproses", admin.get("/admin/orders/1").get_data(as_text=True))
        admin.post("/admin/orders/1/advance", {})
        admin.post("/admin/orders/1/advance", {})
        self.assertIn("Terverifikasi", admin.get("/admin/orders/1").get_data(as_text=True))

    def test_cancel_restores_stock(self):
        cust = self.login("demo@ecovacs.test", "demo123")
        before = self.stock(3)
        self.checkout(cust, pid=3, times=2)
        self.assertEqual(self.stock(3), before - 2)
        cust.post("/orders/1/cancel")
        self.assertEqual(self.stock(3), before)
        r = cust.post("/orders/1/cancel")
        self.assertIn("tidak bisa dibatalkan", r.get_data(as_text=True))

    def test_stock_limit_and_no_access_to_others_orders(self):
        cust = self.login("demo@ecovacs.test", "demo123")
        for _ in range(5):
            cust.post("/cart/add/7")  # stok GOAT A3000 = 3
        self.assertIn("hanya 3 unit", cust.post("/cart/add/7").get_data(as_text=True))
        self.checkout(cust, pid=1)
        other = Client(self.app)
        other.post("/register", {"name": "Lain", "email": "lain@x.id", "password": "secret1", "confirm": "secret1"})
        other.post("/login", {"email": "lain@x.id", "password": "secret1"})
        self.assertEqual(other.c.get("/orders/1").status_code, 404)

    def test_admin_product_crud(self):
        admin = self.login("admin@ecovacs.test", "admin123")
        r = admin.post("/admin/products/new", {"name": "Produk Uji", "category_id": "1", "description": "x",
                                               "price": "1000", "stock": "5", "image": "", "is_active": "on"})
        self.assertIn("Produk ditambahkan", r.get_data(as_text=True))
        r = admin.post("/admin/products/new", {"name": "", "category_id": "1", "price": "1", "stock": "1"})
        self.assertIn("Nama produk wajib", r.get_data(as_text=True))
        admin.post("/admin/products/10/toggle")
        self.assertNotIn("Produk Uji", Client(self.app).get("/products").get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
