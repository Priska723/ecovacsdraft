"""Lapisan data: koneksi SQLite, helper query, dan inisialisasi database."""
import os
import sqlite3

from flask import current_app, g
from werkzeug.security import generate_password_hash

SCHEMA = os.path.join(os.path.dirname(__file__), "schema.sql")

CATEGORIES = [
    ("DEEBOT", "Robot pel & penyedot debu"),
    ("WINBOT", "Robot pembersih jendela"),
    ("GOAT", "Robot pemotong rumput"),
]

# Harga & stok adalah DATA CONTOH untuk keperluan tugas kuliah.
PRODUCTS = [
    ("DEEBOT", "DEEBOT X8 OMNI", "Kecepatan 200 RPM untuk menggosok dan membilas secara efektif hingga ke tepi dan sudut.", 12999000, 10, "deebot1.png"),
    ("DEEBOT", "DEEBOT N30 PRO", "Daya hisap super kuat dan teknologi anti kusut ZEROTANGLE.", 6499000, 8, "deebot-bg22.png"),
    ("DEEBOT", "DEEBOT X11 PRO", "Daya hisap tinggi dengan sistem navigasi TrueePass 4 wheel drive untuk manuver luar biasa.", 17999000, 5, "deboot-bg33.png"),
    ("WINBOT", "WINBOT W2 PRO", "Daya hisap kuat 5500 Pa, hasil lebih bersih dan tanpa kabel.", 5299000, 12, "winbot-bg1.png"),
    ("WINBOT", "WINBOT W2 OMNI", "Memudahkan pembersihan jendela luar ruangan di lantai atas atau jendela yang sulit dijangkau.", 7999000, 9, "winbot-bg2.png"),
    ("WINBOT", "WINBOT W1 PRO", "Daya hisap 2.800 Pa, sistem semprotan air silang ganda, dan navigasi pintar WIN-SLAM 3.0.", 3499000, 15, "winbot-bg3.png"),
    ("GOAT", "GOAT A3000 LIDAR PRO", "Dual-LIDAR 360° memotong halaman otomatis dengan presisi tinggi, bahkan di bawah pohon atau area teduh.", 29999000, 3, "goat1.png"),
    ("GOAT", "GOAT G1-1600", "Robot pemotong rumput otonom untuk halaman menengah hingga besar, luas hingga 1600 m².", 21999000, 4, "goat2.png"),
    ("GOAT", "GOAT O500 Panorama", "Fitur TrueEdge untuk pinggiran rumput yang presisi dan kontrol aplikasi untuk mengatur mode pemotongan.", 24999000, 6, "goat3.png"),
]


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def query(sql, args=(), one=False):
    rows = get_db().execute(sql, args).fetchall()
    if one:
        return rows[0] if rows else None
    return rows


def init_db():
    db = get_db()
    with open(SCHEMA, encoding="utf-8") as f:
        db.executescript(f.read())
    if db.execute("SELECT COUNT(*) FROM categories").fetchone()[0] == 0:
        seed(db)


def seed(db):
    for name, tagline in CATEGORIES:
        db.execute("INSERT INTO categories (name, tagline) VALUES (?, ?)", (name, tagline))
    cat_id = {r["name"]: r["id"] for r in db.execute("SELECT id, name FROM categories")}
    for cat, name, desc, price, stock, image in PRODUCTS:
        db.execute(
            "INSERT INTO products (category_id, name, description, price, stock, image) VALUES (?,?,?,?,?,?)",
            (cat_id[cat], name, desc, price, stock, image),
        )
    db.execute(
        "INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)",
        ("Admin ECOVACS", "admin@ecovacs.test", generate_password_hash("admin123"), "admin"),
    )
    db.execute(
        "INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)",
        ("Pelanggan Demo", "demo@ecovacs.test", generate_password_hash("demo123"), "customer"),
    )
    db.commit()


def init_app(app):
    app.teardown_appcontext(close_db)
    with app.app_context():
        init_db()
