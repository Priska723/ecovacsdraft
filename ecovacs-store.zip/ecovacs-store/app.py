"""ECOVACS Store: toko online dengan arsitektur Layered (MVC).

Lapisan:
  templates/   -> View
  controllers/ -> Controller (routing, validasi input)
  services/    -> Business logic (alur pesanan, stok, pembayaran)
  models/      -> Data access (SQLite)
"""
import os
import secrets

from flask import Flask, abort, g, render_template, request, session, url_for

from config import Config
from controllers.admin import bp as admin_bp
from controllers.auth import bp as auth_bp
from controllers.shop import bp as shop_bp
from models import db as database


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)
    os.makedirs(os.path.dirname(app.config["DATABASE"]), exist_ok=True)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    database.init_app(app)

    for bp in (shop_bp, auth_bp, admin_bp):
        app.register_blueprint(bp)

    @app.before_request
    def load_user():
        uid = session.get("user_id")
        g.user = database.query("SELECT * FROM users WHERE id = ?", (uid,), one=True) if uid else None

    @app.before_request
    def csrf_protect():
        if request.method == "POST":
            token = request.form.get("csrf_token")
            if not token or token != session.get("csrf_token"):
                abort(400)

    @app.context_processor
    def inject():
        if "csrf_token" not in session:
            session["csrf_token"] = secrets.token_hex(16)
        return {
            "csrf_token": session["csrf_token"],
            "cart_count": sum(session.get("cart", {}).values()),
            "payment_info": app.config["PAYMENT_INFO"],
            "payment_methods": app.config["PAYMENT_METHODS"],
        }

    @app.template_filter("rupiah")
    def rupiah(n):
        return "Rp " + f"{int(n):,}".replace(",", ".")

    @app.template_filter("order_code")
    def order_code(n):
        return f"ECO-{int(n):05d}"

    @app.template_filter("slug")
    def slug(s):
        return (s or "").lower().replace(" ", "-")

    @app.template_filter("tgl")
    def tgl(s):
        return (s or "")[:16]

    @app.template_global()
    def img_url(name):
        if not name:
            return url_for("static", filename="img/placeholder.svg")
        if name.startswith("http"):
            return name
        if os.path.exists(os.path.join(app.static_folder, "img", name)):
            return url_for("static", filename=f"img/{name}")
        return app.config["IMAGE_BASE"] + name

    @app.errorhandler(400)
    @app.errorhandler(403)
    @app.errorhandler(404)
    @app.errorhandler(413)
    def error(e):
        msgs = {
            400: "Permintaan tidak valid. Muat ulang halaman lalu coba lagi.",
            403: "Kamu tidak punya akses ke halaman ini.",
            404: "Halaman tidak ditemukan.",
            413: "File terlalu besar. Maksimal 2 MB.",
        }
        return render_template("error.html", code=e.code, message=msgs.get(e.code, "Terjadi kesalahan.")), e.code

    return app


if __name__ == "__main__":
    create_app().run(debug=True)
