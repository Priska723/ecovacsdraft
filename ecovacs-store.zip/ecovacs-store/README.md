# ECOVACS Store

Pengembangan website iklan ECOVACS (statis) menjadi toko online dengan **pembayaran saat checkout**,
**pelacakan status pesanan**, dan **panel admin** untuk menerima serta mengelola pesanan.
Dibuat dengan Python Flask + SQLite. Arsitektur: **Layered (MVC)**.

## Cara menjalankan

Butuh Python 3.9 atau lebih baru.

```bash
cd ecovacs-store
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
python app.py
```

Buka http://127.0.0.1:5000. Database dan data contoh dibuat otomatis saat pertama dijalankan.

| Peran | Email | Kata sandi |
|---|---|---|
| Admin | admin@ecovacs.test | admin123 |
| Pelanggan | demo@ecovacs.test | demo123 |

Ganti kata sandi dan `SECRET_KEY` (di `config.py`) jika aplikasi dipakai di luar demo.
Untuk reset data: hentikan server, hapus `instance/ecovacs.db`, jalankan lagi.

## Pengujian

```bash
python -m unittest discover -s tests -v
```

9 tes otomatis mencakup alur transfer, COD, pembatalan + pengembalian stok, penolakan bukti bayar,
hak akses, proteksi CSRF, batas stok, dan CRUD produk admin.

## Gambar produk

Gambar diambil dari website lama (GitHub Pages) selama ada internet. Agar bisa offline, salin file
gambarnya ke `static/img/` dengan nama yang sama (`deebot1.png`, `winbot-bg1.png`, `goat1.png`, dst.).
Aplikasi otomatis memakai file lokal jika ada.

## Arsitektur (Layered / MVC)

```
Browser
   |
templates/   (View: tampilan Jinja2)
   |
controllers/ (Controller: routing, validasi input, hak akses)   auth.py, shop.py, admin.py
   |
services/    (Business logic: alur status pesanan, stok, pembayaran)   order_service.py
   |
models/      (Data access: SQLite, skema, data awal)   db.py, schema.sql
```

Aturan: controller tidak menulis SQL untuk logika pesanan, semua perubahan status dan stok lewat `services/order_service.py`.

## Alur status pesanan

```
Menunggu Pembayaran --(pelanggan unggah bukti)--> Menunggu Verifikasi
Menunggu Verifikasi --(admin terima)--> Diproses --(admin kirim)--> Dikirim --(pelanggan/admin)--> Selesai
Menunggu Verifikasi --(admin tolak + alasan)--> Menunggu Pembayaran
COD: langsung Diproses
Dibatalkan: pelanggan (saat Menunggu Pembayaran) atau admin (sebelum Dikirim); stok dikembalikan
```

## Struktur database (ERD)

```
users(id, name, email, password_hash, role)
categories(id, name, tagline)
products(id, category_id -> categories, name, description, price, stock, image, is_active)
orders(id, user_id -> users, recipient, phone, address, total, payment_method, status, tracking_no, created_at)
order_items(id, order_id -> orders, product_id -> products, product_name, price, qty)
payments(id, order_id -> orders [1:1], method, status, proof_file, note, paid_at, verified_at)
order_history(id, order_id -> orders, status, note, created_at)
```

Catatan desain: `order_items` menyimpan salinan nama dan harga saat transaksi agar riwayat tidak berubah
jika produk diubah. Keranjang disimpan di session (bukan tabel).

## Fitur

- Pelanggan: daftar/masuk, cari & filter produk, keranjang, checkout (3 metode bayar), unggah bukti bayar,
  lacak status + riwayat, batalkan pesanan, konfirmasi pesanan diterima.
- Admin: dashboard (pendapatan, pesanan per status, produk terlaris, stok menipis), daftar pesanan + filter,
  verifikasi/tolak pembayaran, input resi, ubah status, batalkan, CRUD produk, sembunyikan produk.
- Keamanan dasar: hash kata sandi, token CSRF, validasi tipe file bukti bayar (ekstensi + isi file),
  kontrol akses per peran, stok diperbarui atomik.

## Batasan (jujur untuk laporan)

- Pembayaran adalah simulasi (unggah bukti + verifikasi manual), belum payment gateway.
- Harga, stok, dan nomor rekening adalah data contoh.
- Bukti bayar tersimpan di `static/uploads` dengan nama acak; untuk produksi, simpan di lokasi privat.
- Ide pengembangan lanjutan: integrasi Midtrans sandbox, notifikasi email/WhatsApp, ulasan produk.
